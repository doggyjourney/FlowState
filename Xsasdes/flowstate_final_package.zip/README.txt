FlowState Final Upload Package

Contents:
- mock_decide_server/: Decision server with Gemini injection point and heuristic fallback.
- agent/: Minimal agent that polls every 5 seconds and posts current window to /api/decide.

How to run:
1) Start mock server
   cd mock_decide_server
   npm install
   npm start

2) Start agent in another terminal
   cd agent
   npm install
   # Optional (simulate window):
   # export MOCK_WINDOW_TITLE="Twitter - Home"
   npm start

Notes:
- To wire Gemini: edit mock_decide_server/index.js at the marked "Injection point for Gemini" and call the Gemini API. If Gemini is not configured, the server uses a local heuristic.
- To perform real closes: modify agent/index.js simulateAction() to execute OS-level commands (AppleScript / taskkill) or call Smithery SDK. Smithery examples are commented in mock server file and agent file (placeholders).
- Decision schema returned by /api/decide:
  { decision, action, target, reason, confidence, helpful_links }
  decision: "OK" | "DISTRACTION"
  action: "none" | "close_window" | "popup" | "hide"
