Final Mock Decide Server - README

Usage:
1. Install dependencies:
   cd mock_decide_server
   npm install

2. Start server:
   npm start
   -> Server listens on http://localhost:4000

Behavior:
- POST /api/tasks : create a demo task (returns task_id)
- GET  /api/tasks/latest : returns demo task info
- POST /api/decide : main decision endpoint. If GEMINI integration is configured (see below),
  the server will try to call the model and return model decision. Otherwise, it falls back to
  the local heuristic (blacklist/whitelist + token-overlap).

Gemini integration point:
- Set environment variables (example):
  GEMINI_API_KEY=your_key
  GEMINI_PROJECT=your_project
- Insert model call in the marked injection point in index.js and parse function-calling JSON.
- If the model returns invalid JSON, the server will fall back to heuristic.

Notes on execution:
- The server returns `decision`, `action`, `target`, `reason`, `confidence`, `helpful_links`.
- `action` values: "none" | "close_window" | "popup" | "hide"
- Agent should interpret `close_window` as a request to either show a popup or close the window,
  according to safety policies (e.g., require 2 consecutive DISTRACTION events before closing).
