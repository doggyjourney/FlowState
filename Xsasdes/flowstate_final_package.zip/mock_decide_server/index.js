// mock_decide_server/index.js
// Final version for FlowState hackathon demo
// - Exposes /api/tasks, /api/tasks/latest, /api/decide, /api/tasks/:id/decisions
// - Has a clear injection point for Gemini API (commented) to replace the built-in heuristic
// - If Gemini not configured, uses the simple heuristic (blacklist/whitelist + overlap)
// - Returns JSON: { decision, action, target, reason, confidence, helpful_links }

const express = require('express');
const app = express();
app.use(express.json());
const port = process.env.PORT || 4000;

/* ============
   Configuration: simple heuristic lists and thresholds
   ============ */
const BLACKLIST = ['twitter','youtube','facebook','instagram','tiktok','reddit','netflix'];
const WHITELIST = ['vscode','code','visual studio','pycharm','sublime','terminal','iterm','xcode','idea','stack overflow','stackexchange','docs.google','notion','stackoverflow'];
const OVERLAP_THRESHOLD = 0.25; // 25%

function normalize(s) {
  if(!s) return '';
  return s.toLowerCase().replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
}
function tokens(s) {
  return normalize(s).split(' ').filter(Boolean);
}
function overlapScore(goal, title) {
  const g = new Set(tokens(goal));
  const t = tokens(title);
  if (!g.size || !t.length) return 0;
  let common = 0;
  for (const tok of t) if (g.has(tok)) common++;
  return common / Math.max(g.size, t.length);
}

/* ============
   Endpoints
   ============ */

app.post('/api/tasks', (req, res) => {
  const body = req.body || {};
  const task = {
    task_id: "task_final_001",
    main_goal: body.main_goal || "demo goal",
    status: "running",
    created_at: new Date().toISOString(),
    helpful_links: []
  };
  res.status(201).json(task);
});

app.get('/api/tasks/latest', (req, res) => {
  // For demo, return a static task; in production, hook to DB
  res.json({
    task_id: "task_final_001",
    main_goal: "Fix Bug #105",
    status: "running",
    helpful_links: [],
    last_decision: null
  });
});

/* ============
   Decision endpoint (/api/decide)
   - If GEMINI_API_KEY env var present (or other config), you can inject Gemini API call here.
   - Otherwise fallback to the local heuristic below.
   ============ */

app.post('/api/decide', async (req, res) => {
  const body = req.body || {};
  const main_goal = body.main_goal || '';
  const window_title = body.window_title || '';
  const normTitle = normalize(window_title);

  // === Injection point for Gemini ===
  // If you integrate Gemini, you would:
  // 1) Call Gemini (e.g., via Google Vertex AI or Google Cloud SDK) with a system prompt that
  //    asks the model to return a JSON with fields {decision, action, target, reason, confidence, helpful_links}
  // 2) Parse the model's response (use function-calling or strict JSON output).
  //
  // PSEUDO-CODE (commented, replace with actual SDK calls and parsing):
  //
  // if (process.env.GEMINI_API_KEY) {
  //   const geminiResp = await callGeminiAPI({
  //     system: "You are FlowState Judge. Output ONLY valid JSON with schema ...",
  //     user: { main_goal, window_title }
  //   });
  //   // Parse geminiResp -> resultJson
  //   // if parse OK: return res.json(resultJson);
  //   // else fall through to heuristic
  // }
  //
  // (Make sure to supply GEMINI_API_KEY and any client configuration; see README for details.)

  // === Fallback heuristic (used when Gemini not configured or on parse failure) ===

  // Blacklist check (immediate DISTRACTION)
  for (const bad of BLACKLIST) {
    if (normTitle.includes(bad)) {
      return res.json({
        decision: 'DISTRACTION',
        action: 'close_window',
        target: window_title,
        reason: `Detected blacklisted app/domain: ${bad}`,
        confidence: 95,
        helpful_links: []
      });
    }
  }

  // Whitelist check (productive)
  for (const good of WHITELIST) {
    if (normTitle.includes(good)) {
      return res.json({
        decision: 'OK',
        action: 'none',
        target: window_title,
        reason: `Whitelist matched: ${good}`,
        confidence: 90,
        helpful_links: []
      });
    }
  }

  // Token overlap heuristic
  const score = overlapScore(main_goal, window_title);
  if (score >= OVERLAP_THRESHOLD) {
    return res.json({
      decision: 'OK',
      action: 'none',
      target: window_title,
      reason: `Token overlap between goal and window (${(score*100).toFixed(0)}%)`,
      confidence: Math.min(85, 60 + Math.floor(score*40)),
      helpful_links: main_goal ? [
        { title: 'Sample Help - StackOverflow', url: 'https://stackoverflow.com' }
      ] : []
    });
  }

  // Default: consider distraction
  return res.json({
    decision: 'DISTRACTION',
    action: 'close_window',
    target: window_title,
    reason: `Low token overlap (${(score*100).toFixed(0)}%) with goal`,
    confidence: Math.max(55, 70 - Math.floor(score*40)),
    helpful_links: main_goal ? [
      { title: 'Sample Help - Documentation', url: 'https://example.com/docs' }
    ] : []
  });
});

/* ============
   Decision log endpoint (agent posts execution results)
   ============ */

app.post('/api/tasks/:taskId/decisions', (req, res) => {
  console.log('Decision log received for', req.params.taskId, JSON.stringify(req.body));
  res.json({ ok: true });
});

/* ============
   Server start
   ============ */

app.listen(port, () => {
  console.log(`Final Mock Decide Server listening at http://localhost:${port}`);
});

/* ============
   Notes on close-window execution options:
   - Option A (direct OS commands): implement in the agent (see agent/index.js) using AppleScript (macOS) or taskkill (Windows).
   - Option B (Smithery): call Smithery SDK here or better from the local agent. Replace the agent's simulated action with a smithery.invoke(...) call.
   - For safety, prefer Smithery (manages permissions and gives audit logs). Example Smithery call (pseudo):
     const smith = require('@smithery/sdk')({ apiKey: process.env.SMITHERY_API_KEY });
     await smith.invoke('mcp.flowstate','close_window',{ target: target, reason: reason });
   ============ */
