// agent/index.js
// Minimal agent: every 5 seconds read active window and POST to /api/decide
// SAFE: does not perform destructive actions, only logs the decision and posts execution result

const fetch = require('node-fetch');
require('dotenv').config();
let activeWin;
try { activeWin = require('active-win'); } catch (e) { activeWin = null; }

const DECIDE_URL = process.env.DECIDE_URL || 'http://localhost:4000/api/decide';
const TASKS_URL = process.env.TASKS_URL || 'http://localhost:4000/api/tasks/latest';
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || '5000', 10);

async function getActiveWindowTitle() {
  if (process.env.MOCK_WINDOW_TITLE) return process.env.MOCK_WINDOW_TITLE;
  if (!activeWin) return "Unknown (active-win not installed)";
  try {
    const info = await activeWin();
    return (info && info.title) ? info.title : (info.owner && info.owner.name) ? info.owner.name : "Unknown";
  } catch (e) {
    console.error('active-win error:', e.message || e);
    return "Unknown";
  }
}

async function getLatestTask() {
  try {
    const r = await fetch(TASKS_URL);
    if (r.status === 200) return await r.json();
    return null;
  } catch (e) {
    console.error('Error fetching latest task:', e.message);
    return null;
  }
}

async function postDecisionLog(taskId, decision, performed) {
  try {
    await fetch(`http://localhost:4000/api/tasks/${taskId}/decisions`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ timestamp: new Date().toISOString(), decision, performed })
    });
  } catch (e) {
    console.error('Error posting decision log:', e.message);
  }
}

async function simulateAction(decision) {
  if (!decision) return { status: 'no-op' };
  if (decision.action === 'close_window') {
    console.log(`[SIMULATE] Would close "${decision.target}" - reason: ${decision.reason} - confidence: ${decision.confidence}`);
    return { status: 'simulated', action_result: 'closed' };
  } else if (decision.action === 'popup') {
    console.log(`[SIMULATE] Would show popup: "${decision.reason}"`);
    return { status: 'simulated', action_result: 'popup_shown' };
  } else {
    console.log('[SIMULATE] No action needed (OK).');
    return { status: 'simulated', action_result: 'none' };
  }
}

async function mainLoop() {
  console.log('Minimal FlowState Agent starting. Poll interval:', POLL_INTERVAL, 'ms');
  while (true) {
    const task = await getLatestTask();
    if (!task) {
      console.log('No task found; retrying...');
      await new Promise(r => setTimeout(r, POLL_INTERVAL));
      continue;
    }
    const window_title = await getActiveWindowTitle();
    console.log('Detected active window:', window_title);
    try {
      const resp = await fetch(DECIDE_URL, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ task_id: task.task_id, main_goal: task.main_goal, window_title })
      });
      const decision = await resp.json();
      console.log('Decision received:', decision);
      const performed = await simulateAction(decision);
      await postDecisionLog(task.task_id, decision, performed);
    } catch (e) {
      console.error('Error calling decide endpoint:', e.message || e);
    }
    await new Promise(r => setTimeout(r, POLL_INTERVAL));
  }
}

mainLoop();
